String loginUrlImage = "https://wallpaper.dog/large/17048551.jpg";
String signUpUrlImage = "https://st.depositphotos.com/2464895/2808/i/450/depositphotos_28080461-stock-photo-green-soccer-field-bright-spotlights.jpg";
String? name = "";
String? userImage = "";

